################################################################################
#
#  BFIELD
#
#   Example of plotting the magnitude of the magnetic field
#   produced by a current loop, solving Biot-Savart in cylindrical coordinates (R,Z)
#
################################################################################

import numpy as np
import matplotlib.pyplot as plt
import bfield

# Simple Current Loop, discretized in Npoints
Ra       = 0.05
Center   = np.array([0,0,0])
Angles   = np.array([0,0,0]) * np.pi/180.0
Npoints  = 500  # Increase points for better accuracy
filament = bfield.makeloop( Ra, Center, Angles, Npoints )

current  = 100

# R,Z Grid (cylindrical coordinates)
R = np.linspace(  0.0,   0.1, 50 )
Z = np.linspace( -0.05,  0.05, 50 )
Bnorm = np.zeros((R.size, Z.size))
point = np.zeros((3,1))

for i in range(0, R.size):
    for j in range(0, Z.size):
        point[0] = R[i]  # Convert cylindrical to Cartesian X
        point[1] = 0.0   # Y is zero (on the R-Z plane)
        point[2] = Z[j]  # Z remains Z
        Bx, By, Bz = bfield.biotsavart(filament, current, point)
        Bnorm[i][j] = np.sqrt(Bx*Bx + By*By + Bz*Bz)

plt.figure(1)
RR, ZZ = np.meshgrid(R, Z)
plt.contourf(np.transpose(RR), np.transpose(ZZ), Bnorm, 30)
plt.colorbar()
plt.xlabel('R [m]')
plt.ylabel('Z [m]')
plt.title('B-field magnitude [T] of a Current Loop (Biot-Savart)')
plt.savefig('ex09_plot_filament_simple_loop_fixed.png', dpi=150)
plt.show()
